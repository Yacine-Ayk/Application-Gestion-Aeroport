
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Réservation extends javax.swing.JFrame {

    Connecter conn=new Connecter();
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model=new DefaultTableModel();
    
   
    private String date_réservation;
    private String CIN_Client;
    private String num_Vol;
    
     
    public Réservation() {
        initComponents();

model.addColumn("date_réservation");
model.addColumn("CIN_Client");
model.addColumn("num_Vol");


try {
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from réservation");
while(Rs.next()){
    
model.addRow(new Object[]{Rs.getString("date_réservation"), Rs.getString("CIN_Client"),Rs.getString("num_Vol")});

}
}catch(Exception e){System.err.println(e);}

tble_réserv.setModel(model);
        
    }

   
    @SuppressWarnings("unchecked")
   
    private void deplace(int i){
     try{
       jFormattedDate_réserv.setText(model.getValueAt(i,0).toString());
       txtcin.setText(model.getValueAt(i,1).toString());
       txtnum_vol.setText(model.getValueAt(i,2).toString());
       
     } catch (Exception e) {System.err.println(e);
     JOptionPane.showMessageDialog(null,"erreur de deplacement"+e.getLocalizedMessage());}   
        
    }
    
   private void afficher(){
        try {
       model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from réservation");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("date_réservation"),Rs.getString("CIN_Client"),
 Rs.getString("num_Vol")});

}
}catch(Exception e){System.err.println(e);}

tble_réserv.setModel(model);
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tble_réserv = new javax.swing.JTable();
        matr = new javax.swing.JLabel();
        txtcin = new javax.swing.JTextField();
        matr1 = new javax.swing.JLabel();
        matr2 = new javax.swing.JLabel();
        txtnum_vol = new javax.swing.JTextField();
        Btn_ajouterRéserv = new javax.swing.JButton();
        Btn_modifRéserv = new javax.swing.JButton();
        Btn_supprimRéser = new javax.swing.JButton();
        Btn_retour = new javax.swing.JButton();
        Btn_actualiser = new javax.swing.JButton();
        jFormattedDate_réserv = new javax.swing.JFormattedTextField();
        Btn_quitter = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        Btn_validerRechercher1 = new javax.swing.JButton();
        txtrech = new javax.swing.JTextField();
        comrech = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setText("Espace réservations");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 300, 40));

        tble_réserv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        tble_réserv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tble_réservMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tble_réserv);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(291, 77, -1, 204));

        matr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr.setText("CIN_Client");
        getContentPane().add(matr, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 89, -1));

        txtcin.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtcin, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 96, -1));

        matr1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr1.setText("Num_vol");
        getContentPane().add(matr1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 89, -1));

        matr2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr2.setText("Date_réservation");
        getContentPane().add(matr2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, -1, -1));

        txtnum_vol.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtnum_vol, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 96, -1));

        Btn_ajouterRéserv.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_ajouterRéserv.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\plus.png")); // NOI18N
        Btn_ajouterRéserv.setText("Ajouter");
        Btn_ajouterRéserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ajouterRéservActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_ajouterRéserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(68, 359, 112, 35));

        Btn_modifRéserv.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_modifRéserv.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\modifier.png")); // NOI18N
        Btn_modifRéserv.setText("Modifier");
        Btn_modifRéserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_modifRéservActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_modifRéserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(231, 359, -1, 35));

        Btn_supprimRéser.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_supprimRéser.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\delete.png")); // NOI18N
        Btn_supprimRéser.setText("Supprimer");
        Btn_supprimRéser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_supprimRéserActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_supprimRéser, new org.netbeans.lib.awtextra.AbsoluteConstraints(576, 360, -1, -1));

        Btn_retour.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btn_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(696, 432, -1, -1));

        Btn_actualiser.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_actualiser.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\refresh.png")); // NOI18N
        Btn_actualiser.setText("Actualiser");
        Btn_actualiser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_actualiserActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_actualiser, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 359, -1, 35));

        try {
            jFormattedDate_réserv.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedDate_réserv.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(jFormattedDate_réserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 99, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 432, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Rechercher par:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 224, -1, -1));

        Btn_validerRechercher1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_validerRechercher1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\rechercher.png")); // NOI18N
        Btn_validerRechercher1.setText("Rechercher");
        Btn_validerRechercher1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_validerRechercher1ActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_validerRechercher1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 254, -1, 34));

        txtrech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrechActionPerformed(evt);
            }
        });
        getContentPane().add(txtrech, new org.netbeans.lib.awtextra.AbsoluteConstraints(157, 262, 128, -1));

        comrech.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "date_réservation", "CIN_Client", "num_vol", " " }));
        comrech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comrechActionPerformed(evt);
            }
        });
        getContentPane().add(comrech, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 117, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\espaceclient canva 6 (1).png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_modifRéservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_modifRéservActionPerformed
        // modifier
         try {
            if (JOptionPane.showConfirmDialog (null,"confirmer la modification","modification",
                JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {

stm.executeUpdate("UPDATE réservation SET date_réservation='"+jFormattedDate_réserv.getText()+"'"
        + " where CIN_Client = '"+txtcin.getText()+"'and num_Vol= "+txtnum_vol.getText());
  // afficher();

        }
        } catch (Exception e){JOptionPane.showMessageDialog(null,"erreur de modification !!!!!!!"+e.getMessage());
            System.err.println(e);}
       
    }//GEN-LAST:event_Btn_modifRéservActionPerformed

    private void Btn_ajouterRéservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ajouterRéservActionPerformed
        //  ajouter
      
        String date_réservation=jFormattedDate_réserv.getText();
        String CIN_Client=txtcin.getText();
        String num_Vol=txtnum_vol.getText();
        
  String requete="insert into réservation(date_réservation,CIN_Client,num_Vol)"
          + "VALUES('"+date_réservation+"','"+CIN_Client+"','"+num_Vol+"')";

        try{
            stm=conn.obtenirconnexion().createStatement();
            stm.executeUpdate(requete);
            JOptionPane.showMessageDialog(null,"la réservation a bien été ajoutée");

            jFormattedDate_réserv.setText("");
            txtcin.setText("");
            txtnum_vol.setText("");
           

             //afficher();

        }catch(Exception ex){JOptionPane.showMessageDialog(null,ex.getMessage());}
        
   
        
    }//GEN-LAST:event_Btn_ajouterRéservActionPerformed

    private void Btn_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btn_retourActionPerformed

    private void Btn_actualiserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_actualiserActionPerformed
        // actualiser
       try {
model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("select * from réservation");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("date_réservation"),Rs.getString("CIN_Client"),Rs.getString("num_Vol")});
afficher();

}
}catch(Exception e){System.err.println(e);}

tble_réserv.setModel(model);
        
    }//GEN-LAST:event_Btn_actualiserActionPerformed

    private void Btn_supprimRéserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_supprimRéserActionPerformed
        // Boutoon supprimer une réservation
        
       try {
            if(JOptionPane.showConfirmDialog(null,"Attention!!! Etes-vous sûr de vouloir supprimer une réservation ?"
                ,"supprimer réservation",JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)

        if(txtnum_vol.getText().length() != 0){
 stm.executeUpdate("Delete From réservation where date_réservation = '"+jFormattedDate_réserv.getText()+"'and num_Vol= "+txtnum_vol.getText());
                           
            afficher();

        }
        else { JOptionPane.showMessageDialog(null,"veuillez SVP remplir le champ num_vol !");}

        }catch (Exception e){JOptionPane.showMessageDialog(null,"erreur de supprimer \n"+e.getMessage());}

    }//GEN-LAST:event_Btn_supprimRéserActionPerformed

    private void tble_réservMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tble_réservMouseClicked
try{
            int i=tble_réserv.getSelectedRow(); deplace(i);
        }
        catch(Exception e){JOptionPane.showMessageDialog(null,"erreur de deplacement "+e.getLocalizedMessage());}
    }//GEN-LAST:event_tble_réservMouseClicked

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    private void Btn_validerRechercher1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_validerRechercher1ActionPerformed
        // Trechercher
        
        if (txtrech.getText().equals(" ")) {
            JOptionPane.showMessageDialog(this, "SVP entrer quelque chose");
        }
        else {

            if (comrech.getSelectedItem().equals("date_réservation")) {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from réservation WHERE date_réservation= '"+txtrech.getText()+"'");}
                    while (Rs.next()){
                        Object [] réservation ={Rs.getInt(1),Rs.getString(2),Rs.getString(3)};
                        model.addRow(réservation);
                    }
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage());}
            }

            else if (comrech.getSelectedItem().equals("CIN_Client"))  {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from réservation WHERE CIN_Client = '"+txtrech.getText()+"'"); }
                    while (Rs.next()){
                        Object []  réservation ={Rs.getInt(1),Rs.getString(2),Rs.getString(3)};
                        model.addRow(réservation);}
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage());}
            }

            else    {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from réservation WHERE num_Vol = '"+txtrech.getText()+"'");}
                    while (Rs.next()){
                        Object [] réservation ={Rs.getInt(1),Rs.getString(2),Rs.getString(3)};
                        model.addRow(réservation); }
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage()); }
            }
        }
    }//GEN-LAST:event_Btn_validerRechercher1ActionPerformed

    private void txtrechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrechActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrechActionPerformed

    private void comrechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comrechActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comrechActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Réservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Réservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Réservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Réservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Réservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_actualiser;
    private javax.swing.JButton Btn_ajouterRéserv;
    private javax.swing.JButton Btn_modifRéserv;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JButton Btn_retour;
    private javax.swing.JButton Btn_supprimRéser;
    private javax.swing.JButton Btn_validerRechercher1;
    private javax.swing.JComboBox<String> comrech;
    private javax.swing.JFormattedTextField jFormattedDate_réserv;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel matr;
    private javax.swing.JLabel matr1;
    private javax.swing.JLabel matr2;
    private javax.swing.JTable tble_réserv;
    private javax.swing.JTextField txtcin;
    private javax.swing.JTextField txtnum_vol;
    private javax.swing.JTextField txtrech;
    // End of variables declaration//GEN-END:variables
}
