package base_de_données;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AjoutClient extends javax.swing.JFrame {

    Connecter conn=new Connecter();
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model=new DefaultTableModel();
    /**
     * Creates new form AjoutClient
     */
    public AjoutClient() {
        initComponents();
        
model.addColumn("CIN_Client");
model.addColumn("nom");
model.addColumn("prénom");
model.addColumn("num_Passeport");

try {
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from client");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("CIN_Client"),Rs.getString("nom"),Rs.getString("prénom"),
    Rs.getString("num_Passeport") });

}
}catch(Exception e){System.err.println(e);}

tble_client.setModel(model);
    }

    
    @SuppressWarnings("unchecked")
    
     private void deplace(int i){
     try{
       txtcin.setText(model.getValueAt(i,0).toString());
       txtno.setText(model.getValueAt(i,1).toString());
       txtpr.setText(model.getValueAt(i,2).toString());
       txtnum_pas.setText(model.getValueAt(i,3).toString());
       
 
     } catch (Exception e) {System.err.println(e);
     JOptionPane.showMessageDialog(null,"erreur de deplacement"+e.getLocalizedMessage());}   
        
    }
     
     private void afficher(){
        try {
       model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from client");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("CIN_Client"),Rs.getString("nom"),Rs.getString("prénom"),
   Rs.getString("num_Passeport")});

}
}catch(Exception e){System.err.println(e);}

tble_client.setModel(model);
    }
   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tble_client = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtno = new javax.swing.JTextField();
        txtpr = new javax.swing.JTextField();
        txtnum_pas = new javax.swing.JTextField();
        matr = new javax.swing.JLabel();
        no = new javax.swing.JLabel();
        pré = new javax.swing.JLabel();
        adr = new javax.swing.JLabel();
        txtcin = new javax.swing.JTextField();
        Btn_réservVol = new javax.swing.JButton();
        Btm_actualiser = new javax.swing.JButton();
        Btn_ajouterClient = new javax.swing.JButton();
        Btm_retour = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tble_client.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tble_client.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tble_clientMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tble_client);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(296, 80, 443, 229));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("Espace Clients");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(268, 11, 181, -1));

        txtno.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtno, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 93, -1));

        txtpr.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtpr, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 93, -1));

        txtnum_pas.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtnum_pas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnum_pasActionPerformed(evt);
            }
        });
        getContentPane().add(txtnum_pas, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 93, -1));

        matr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr.setText("CIN_Client");
        getContentPane().add(matr, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, 89, -1));

        no.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        no.setText("Nom");
        getContentPane().add(no, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, -1, -1));

        pré.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        pré.setText("Prénom");
        getContentPane().add(pré, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        adr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        adr.setText("Num_Passeport");
        getContentPane().add(adr, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 103, -1));

        txtcin.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtcin, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 93, -1));

        Btn_réservVol.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btn_réservVol.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\réserver un vol 1.png")); // NOI18N
        Btn_réservVol.setText("Réserver un vol");
        Btn_réservVol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_réservVolActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_réservVol, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 360, -1, 34));

        Btm_actualiser.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_actualiser.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\refresh.png")); // NOI18N
        Btm_actualiser.setText("Actualiser");
        Btm_actualiser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_actualiserActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_actualiser, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 360, -1, 34));

        Btn_ajouterClient.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btn_ajouterClient.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\plus.png")); // NOI18N
        Btn_ajouterClient.setText("Ajouter");
        Btn_ajouterClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ajouterClientActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_ajouterClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 118, 34));

        Btm_retour.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btm_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 432, -1, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 432, 48, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\admin 1.png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tble_clientMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tble_clientMouseClicked
        // table de la liste des clients
        try{
            int i=tble_client.getSelectedRow(); deplace(i);
        }
        catch(Exception e){JOptionPane.showMessageDialog(null,"erreur de deplacement "+e.getLocalizedMessage());}
    }//GEN-LAST:event_tble_clientMouseClicked

    private void txtnum_pasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnum_pasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnum_pasActionPerformed

    private void Btm_actualiserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_actualiserActionPerformed
        // actualiser 
       try {
model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("select * from client");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("CIN_Client"),Rs.getString("nom"),Rs.getString("prénom"),
 Rs.getString("num_Passeport")});
afficher();

}
}catch(Exception e){System.err.println(e);}

tble_client.setModel(model);
    }//GEN-LAST:event_Btm_actualiserActionPerformed

    private void Btn_réservVolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_réservVolActionPerformed
        // lafenetre réservation s'ouvre
        Réservation fenetre_réserv= new Réservation();
        fenetre_réserv.setLocationRelativeTo(null);
        fenetre_réserv.setVisible(true);
    }//GEN-LAST:event_Btn_réservVolActionPerformed

    private void Btn_ajouterClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ajouterClientActionPerformed
        // ajouter un client

        String cin=txtcin.getText();
        String nom=txtno.getText();
        String prénom=txtpr.getText();
        String numpas=txtnum_pas.getText();
        
    if( cin.trim().isEmpty() || nom.trim().isEmpty() || prénom.trim().isEmpty() || numpas.trim().isEmpty() ){
     JOptionPane.showMessageDialog(null,"Veuillez remplir tous les champs SVP!!!");
    }else{
        String requete="insert into client(CIN_Client,nom,prénom,num_Passeport)VALUES('"+cin+"','"+nom+"','"+prénom+"','"+numpas+"')";
        
        try{
            stm=conn.obtenirconnexion().createStatement();
            stm.executeUpdate(requete);
            JOptionPane.showMessageDialog(null,"le client a bien été ajouté");

            txtcin.setText("");
            txtno.setText("");
            txtpr.setText("");
            txtnum_pas.setText("");

            //afficher();

        }catch(Exception ex){JOptionPane.showMessageDialog(null,ex.getMessage());}
            }
            
    }//GEN-LAST:event_Btn_ajouterClientActionPerformed

    private void Btm_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btm_retourActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AjoutClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AjoutClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AjoutClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AjoutClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AjoutClient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btm_actualiser;
    private javax.swing.JButton Btm_retour;
    private javax.swing.JButton Btn_ajouterClient;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JButton Btn_réservVol;
    private javax.swing.JLabel adr;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel matr;
    private javax.swing.JLabel no;
    private javax.swing.JLabel pré;
    private javax.swing.JTable tble_client;
    private javax.swing.JTextField txtcin;
    private javax.swing.JTextField txtno;
    private javax.swing.JTextField txtnum_pas;
    private javax.swing.JTextField txtpr;
    // End of variables declaration//GEN-END:variables
}
