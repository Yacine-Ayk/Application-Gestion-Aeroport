
package base_de_données;

public class Principale extends javax.swing.JFrame {

    public Principale() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Btn_client = new javax.swing.JButton();
        Btn_administrateur = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Application de gestion de l'aéroport");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 710, 59));

        Btn_client.setBackground(new java.awt.Color(153, 204, 255));
        Btn_client.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_client.setText("Je suis un client");
        Btn_client.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_clientActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_client, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 310, 33));

        Btn_administrateur.setBackground(new java.awt.Color(153, 204, 255));
        Btn_administrateur.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_administrateur.setText("Je suis un administrateur");
        Btn_administrateur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_administrateurActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_administrateur, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 310, 33));

        jLabel5.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 10)); // NOI18N
        jLabel5.setText("Réalisé par: ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 390, -1, 30));

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        jLabel6.setText("AYEKOUNI Yacine");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 380, 180, 50));

        jLabel7.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 10)); // NOI18N
        jLabel7.setText("Génie des Systèmes de Réseaux et Télécommunications");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 440, 310, -1));

        jLabel8.setFont(new java.awt.Font("Microsoft JhengHei Light", 1, 10)); // NOI18N
        jLabel8.setText("Ecole Nationale des Sciences appliquées de Tanger");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, -1, 20));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\principale3.png")); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_clientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_clientActionPerformed
       // lafenetre Client s'ouvre
        Client fenetre_c= new Client();
        fenetre_c.setLocationRelativeTo(null); //pour mettre la fenetre au milieu
        fenetre_c.setVisible(true);
    }//GEN-LAST:event_Btn_clientActionPerformed

    private void Btn_administrateurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_administrateurActionPerformed
 // fenetre login
        Login fenetre_login = new Login();
        fenetre_login.setLocationRelativeTo(null); // pour mettre la fenetre au milieu
        fenetre_login.setVisible(true);        
    }//GEN-LAST:event_Btn_administrateurActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principale().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_administrateur;
    private javax.swing.JButton Btn_client;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration//GEN-END:variables
}
