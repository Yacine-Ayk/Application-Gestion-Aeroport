package base_de_données;

import java.util.Date;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Réservation_Client extends javax.swing.JFrame {

    Connecter conn=new Connecter();
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model=new DefaultTableModel();
    
   
    private String date_réservation;
    private String CIN_Client;
    private String num_Vol;
    
     
    public Réservation_Client() {
        initComponents();

model.addColumn("date_réservation");
model.addColumn("CIN_Client");
model.addColumn("num_Vol");

/*
try {
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from réservation");
while(Rs.next()){
    
model.addRow(new Object[]{Rs.getString("date_réservation"), Rs.getString("CIN_Client"),Rs.getString("num_Vol")});

}
}catch(Exception e){System.err.println(e);}
*/
//tble_réserv.setModel(model);
        
    }

   
    @SuppressWarnings("unchecked")
   
    private void deplace(int i){
     try{
       txtdate.setText(model.getValueAt(i,0).toString());
       txtcin.setText(model.getValueAt(i,1).toString());
       txtnum_vol.setText(model.getValueAt(i,2).toString());
       
     } catch (Exception e) {System.err.println(e);
     JOptionPane.showMessageDialog(null,"erreur de deplacement"+e.getLocalizedMessage());}   
        
    }
    
   private void afficher(){
        try {
model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from réservation");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("date_réservation"),Rs.getString("CIN_Client"),
 Rs.getString("num_Vol")});

}
}catch(Exception e){System.err.println(e);}

//tble_réserv.setModel(model);
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtdate = new javax.swing.JTextField();
        matr = new javax.swing.JLabel();
        matr1 = new javax.swing.JLabel();
        matr2 = new javax.swing.JLabel();
        txtnum_vol = new javax.swing.JTextField();
        Btn_ajouterRéserv = new javax.swing.JButton();
        Btn_retour = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        txtcin = new javax.swing.JTextField();
        jLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setText("Espace réservations");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 300, 40));

        txtdate.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtdate.setText("YYYY-MM-DD");
        getContentPane().add(txtdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, 150, -1));
        txtdate.getAccessibleContext().setAccessibleDescription("yyyy-mm-dd");

        matr.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        matr.setText("CIN_Client");
        getContentPane().add(matr, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 89, -1));

        matr1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        matr1.setText("Num_vol");
        getContentPane().add(matr1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 89, -1));

        matr2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        matr2.setText("Date_réservation");
        getContentPane().add(matr2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, -1, -1));

        txtnum_vol.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtnum_vol, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 150, -1));

        Btn_ajouterRéserv.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_ajouterRéserv.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\plus.png")); // NOI18N
        Btn_ajouterRéserv.setText("Ajouter");
        Btn_ajouterRéserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ajouterRéservActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_ajouterRéserv, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 310, 112, 35));

        Btn_retour.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btn_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 370, -1, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, -1, -1));

        txtcin.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtcin, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, 150, -1));

        jLabel.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(jLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 330, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\espaceclient canva 6 (1).png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_ajouterRéservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ajouterRéservActionPerformed
        //  ajouter
      
        String date_réservation=txtdate.getText();
        String CIN_Client=txtcin.getText();
        String num_Vol=txtnum_vol.getText();
     
        if( date_réservation.trim().isEmpty() || CIN_Client.trim().isEmpty() || num_Vol.trim().isEmpty() ){
            JOptionPane.showMessageDialog(null,"Veuillez remplir tous les champs SVP!!!");
    }else{
            SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
            Date d1=null;
            
            try{ 
            d1 = sdformat.parse(date_réservation);
            }catch (ParseException ex) {
              // Logger.getLogger(Réservation_Client.class.getName()).log(Level.SEVERE,null,ex);
             JOptionPane.showMessageDialog(null,"Format de la date incorrect");  
              //jLabel.setText("Format de la date incorrect, yyyy-MM-dd");
             // jLabel.setVisible(true);
            }
              
        String requete="insert into réservation(date_réservation,CIN_Client,num_Vol)"
          + "VALUES('"+date_réservation+"','"+CIN_Client+"','"+num_Vol+"')";

        try{
            stm=conn.obtenirconnexion().createStatement();
            stm.executeUpdate(requete);
            JOptionPane.showMessageDialog(null,"Votre réservation a bien été enrégistrée. Merci de votre visite");

            txtdate.setText("");
            txtcin.setText("");
            txtnum_vol.setText("");
           
             //afficher();

        }catch(Exception ex){JOptionPane.showMessageDialog(null,ex.getMessage());}
        
  }
        
    }//GEN-LAST:event_Btn_ajouterRéservActionPerformed

    private void Btn_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btn_retourActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Réservation_Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Réservation_Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Réservation_Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Réservation_Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Réservation_Client().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_ajouterRéserv;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JButton Btn_retour;
    private javax.swing.JLabel jLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel matr;
    private javax.swing.JLabel matr1;
    private javax.swing.JLabel matr2;
    private javax.swing.JTextField txtcin;
    private javax.swing.JTextField txtdate;
    private javax.swing.JTextField txtnum_vol;
    // End of variables declaration//GEN-END:variables
}
