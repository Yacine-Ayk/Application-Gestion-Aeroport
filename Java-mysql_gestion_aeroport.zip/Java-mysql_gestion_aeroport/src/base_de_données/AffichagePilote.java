package base_de_données;


import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class AffichagePilote extends javax.swing.JFrame {

    Connecter conn=new Connecter();
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model=new DefaultTableModel();
    
    
    public AffichagePilote() {
        initComponents();
        
        
model.addColumn("matricule");
model.addColumn("nom");
model.addColumn("prénom");
model.addColumn("adresse");
try {
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from pilote");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
    Rs.getString("adresse")});

}
}catch(Exception e){System.err.println(e);}

tble_pilote.setModel(model);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tble_pilote = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        matr = new javax.swing.JLabel();
        no = new javax.swing.JLabel();
        pré = new javax.swing.JLabel();
        adr = new javax.swing.JLabel();
        txtma = new javax.swing.JTextField();
        txtno = new javax.swing.JTextField();
        txtpr = new javax.swing.JTextField();
        txtad = new javax.swing.JTextField();
        Btm_supprimPilote = new javax.swing.JButton();
        Btm_ActualiserPilote = new javax.swing.JButton();
        Btm_modifPilote = new javax.swing.JButton();
        Btm_retour = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        comrech = new javax.swing.JComboBox<>();
        Btn_validerRechercher1 = new javax.swing.JButton();
        txtrech = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(new java.awt.Dimension(0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tble_pilote.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tble_pilote.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tble_piloteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tble_pilote);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 66, 443, 129));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("Espace pilotes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, 173, -1));

        matr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr.setText("matricule");
        getContentPane().add(matr, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, -1));

        no.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        no.setText("nom");
        getContentPane().add(no, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 49, 21));

        pré.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        pré.setText("prénom");
        getContentPane().add(pré, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 63, -1));

        adr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        adr.setText("adresse");
        getContentPane().add(adr, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        txtma.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtma, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 153, -1));

        txtno.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtno, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 153, -1));

        txtpr.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtpr, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 153, -1));

        txtad.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtadActionPerformed(evt);
            }
        });
        getContentPane().add(txtad, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 153, -1));

        Btm_supprimPilote.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_supprimPilote.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\delete.png")); // NOI18N
        Btm_supprimPilote.setText("Supprimer");
        Btm_supprimPilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_supprimPiloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_supprimPilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 350, -1, 32));

        Btm_ActualiserPilote.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_ActualiserPilote.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\refresh.png")); // NOI18N
        Btm_ActualiserPilote.setText("Actualiser");
        Btm_ActualiserPilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_ActualiserPiloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_ActualiserPilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, -1, 32));

        Btm_modifPilote.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_modifPilote.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\modifier.png")); // NOI18N
        Btm_modifPilote.setText("Modifier");
        Btm_modifPilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_modifPiloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_modifPilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 350, -1, 32));

        Btm_retour.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btm_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(756, 396, 46, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 396, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Rechercher par:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, -1, 27));

        comrech.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "matricule", "nom", "prénom", "adresse" }));
        comrech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comrechActionPerformed(evt);
            }
        });
        getContentPane().add(comrech, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 87, -1));

        Btn_validerRechercher1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_validerRechercher1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\rechercher.png")); // NOI18N
        Btn_validerRechercher1.setText("Rechercher");
        Btn_validerRechercher1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_validerRechercher1ActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_validerRechercher1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 140, -1));

        txtrech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrechActionPerformed(evt);
            }
        });
        getContentPane().add(txtrech, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 290, 130, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\admin 2.png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 430));

        pack();
    }// </editor-fold>//GEN-END:initComponents

  
   private void deplace(int i){
     try{
       txtma.setText(model.getValueAt(i,0).toString());
       txtno.setText(model.getValueAt(i,1).toString());
       txtpr.setText(model.getValueAt(i,2).toString());
       txtad.setText(model.getValueAt(i,3).toString());
 
     } catch (Exception e) {System.err.println(e);
     JOptionPane.showMessageDialog(null,"erreur de deplacement"+e.getLocalizedMessage());}   
        
    }
    
   private void afficher(){
        try {
       model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from pilote");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
 Rs.getString("adresse")});

}
}catch(Exception e){System.err.println(e);}

tble_pilote.setModel(model);
    }
  
   
    
    private void tble_piloteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tble_piloteMouseClicked
        // table de la liste des pilotes
         try{
      int i=tble_pilote.getSelectedRow(); deplace(i);
         }
      catch(Exception e){JOptionPane.showMessageDialog(null,"erreur de deplacement "+e.getLocalizedMessage());}
    }//GEN-LAST:event_tble_piloteMouseClicked

    private void txtadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtadActionPerformed

    private void Btm_supprimPiloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_supprimPiloteActionPerformed
        // suppimer un pilote
         try {
             if(JOptionPane.showConfirmDialog(null,"Attention!!! Etes-vous sûr de vouloir supprimer un pilote?"
                     ,"supprimer pilote",JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)
         
            if(txtma.getText().length() != 0){
        stm.executeUpdate("Delete From pilote where matricule = "+txtma.getText());
        
         //afficher();
         
             }
            else { JOptionPane.showMessageDialog(null,"veuillez SVP remplir le champ matricule !");}
        
        }catch (Exception e){JOptionPane.showMessageDialog(null,"erreur de supprimer \n"+e.getMessage());} 
       
    }//GEN-LAST:event_Btm_supprimPiloteActionPerformed

    private void Btm_ActualiserPiloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_ActualiserPiloteActionPerformed
  // actualiser
        try {
       model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from pilote");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
    Rs.getString("adresse")});
afficher();

}
}catch(Exception e){System.err.println(e);}

tble_pilote.setModel(model);
    }//GEN-LAST:event_Btm_ActualiserPiloteActionPerformed

    private void Btm_modifPiloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_modifPiloteActionPerformed
       //modifier
        String ma=txtma.getText();
        String nom=txtno.getText();
        String prénom=txtpr.getText();
        String ad=txtad.getText();
if( ma.trim().isEmpty() || nom.trim().isEmpty() || prénom.trim().isEmpty() || ad.trim().isEmpty() ){
     JOptionPane.showMessageDialog(null,"Veuillez remplir tous les champs SVP!!!");
    }else{
        try { 
            if (JOptionPane.showConfirmDialog (null,"confirmer la modification","modification",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {

                stm.executeUpdate("UPDATE pilote SET nom='"+txtno.getText()+
                        "',prénom='"+txtpr.getText()+"',adresse='"+txtad.getText()+
                         "'WHERE matricule= "+txtma.getText());
               // afficher();
            
            } 
        } catch (Exception e){JOptionPane.showMessageDialog(null,"erreur de modification !!!!!!!"+e.getMessage());
        System.err.println(e);}
}
    }//GEN-LAST:event_Btm_modifPiloteActionPerformed

    private void Btm_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btm_retourActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
       System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    private void Btn_validerRechercher1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_validerRechercher1ActionPerformed
        // Rechercher un pilote par

        if (txtrech.getText().equals(" ")) {
            JOptionPane.showMessageDialog(this, "SVP entrer quelque chose");
        }
        else {

            if (comrech.getSelectedItem().equals("matricule")) {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from pilote WHERE matricule = '"+txtrech.getText()+"'");}
                    while (Rs.next()){
                        Object [] pilote ={Rs.getInt(1),Rs.getString(2),Rs.getString(3),Rs.getString(4)};
                        model.addRow(pilote);
                    }
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage());}
            }

            else if (comrech.getSelectedItem().equals("nom"))  {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from pilote WHERE nom = '"+txtrech.getText()+"'");}
                    while (Rs.next()){
                        Object [] pilote ={Rs.getInt(1),Rs.getString(2),Rs.getString(3),Rs.getString(4)};
                        model.addRow(pilote);
                    }
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage());}
            }

            else if (comrech.getSelectedItem().equals("prénom"))  {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from pilote WHERE prénom = '"+txtrech.getText()+"'"); }
                    while (Rs.next()){
                        Object [] pilote ={Rs.getInt(1),Rs.getString(2),Rs.getString(3),Rs.getString(4)};
                        model.addRow(pilote);}
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage());}
            }

            else if (comrech.getSelectedItem().equals("adresse"))  {
                try {
                    model.setRowCount(0);
                    {Rs = stm.executeQuery("Select * from pilote WHERE adresse = '"+txtrech.getText()+"'");}
                    while (Rs.next()){
                        Object [] pilote ={Rs.getInt(1),Rs.getString(2),Rs.getString(3),Rs.getString(4)};
                        model.addRow(pilote); }
                }catch (Exception e) { System.err.println(e);
                    JOptionPane.showMessageDialog(null,e.getMessage()); }
            }
        }
    }//GEN-LAST:event_Btn_validerRechercher1ActionPerformed

    private void txtrechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrechActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrechActionPerformed

    private void comrechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comrechActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comrechActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AffichagePilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AffichagePilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AffichagePilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AffichagePilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AffichagePilote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btm_ActualiserPilote;
    private javax.swing.JButton Btm_modifPilote;
    private javax.swing.JButton Btm_retour;
    private javax.swing.JButton Btm_supprimPilote;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JButton Btn_validerRechercher1;
    private javax.swing.JLabel adr;
    private javax.swing.JComboBox<String> comrech;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel matr;
    private javax.swing.JLabel no;
    private javax.swing.JLabel pré;
    private javax.swing.JTable tble_pilote;
    private javax.swing.JTextField txtad;
    private javax.swing.JTextField txtma;
    private javax.swing.JTextField txtno;
    private javax.swing.JTextField txtpr;
    private javax.swing.JTextField txtrech;
    // End of variables declaration//GEN-END:variables
}
