
package base_de_données;


public class Client extends javax.swing.JFrame {

   
    public Client() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Btn_affichagevol = new javax.swing.JButton();
        Btn_faireRéservation = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Btn_inscrire = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Btn_affichagevol.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        Btn_affichagevol.setText("Voir tous les vols");
        Btn_affichagevol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_affichagevolActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_affichagevol, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 166, 207, -1));

        Btn_faireRéservation.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        Btn_faireRéservation.setText("Faire une réservation");
        Btn_faireRéservation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_faireRéservationActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_faireRéservation, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 232, 210, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 280, 50, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setText("Menu ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        Btn_inscrire.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        Btn_inscrire.setText("M'inscrire");
        Btn_inscrire.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_inscrireActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_inscrire, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 101, 207, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\espaceclient canva 6 (1).png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 310));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_affichagevolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_affichagevolActionPerformed
        AffichageVolClient fenetre_affichvols = new AffichageVolClient();
        fenetre_affichvols.setLocationRelativeTo(null);
        fenetre_affichvols.setVisible(true); 
        
        //ouvrir l'interface des villes
         AffichVilles fenetre_affichv = new AffichVilles();
         fenetre_affichv.setLocationRelativeTo(null);
        fenetre_affichv.setVisible(true);
    }//GEN-LAST:event_Btn_affichagevolActionPerformed

    private void Btn_faireRéservationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_faireRéservationActionPerformed
         // lafenetre réservation_client s'ouvre
        Réservation_Client fenetre_réserv= new Réservation_Client();
        fenetre_réserv.setLocationRelativeTo(null);
        fenetre_réserv.setVisible(true);
    }//GEN-LAST:event_Btn_faireRéservationActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    private void Btn_inscrireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_inscrireActionPerformed
         // lafenetre af s'ouvre
        AjoutClient_Client fenetre_aj= new AjoutClient_Client();
        fenetre_aj.setLocationRelativeTo(null);
        fenetre_aj.setVisible(true);
    }//GEN-LAST:event_Btn_inscrireActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Client().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_affichagevol;
    private javax.swing.JButton Btn_faireRéservation;
    private javax.swing.JButton Btn_inscrire;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
