package base_de_données;



public class Espace_pilote extends javax.swing.JFrame {

    public Espace_pilote() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Btn_ajouter_pilote = new javax.swing.JButton();
        Btn_afficher_pilote = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Btm_retour = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Btn_ajouter_pilote.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_ajouter_pilote.setText("Ajouter un pilote");
        Btn_ajouter_pilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ajouter_piloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_ajouter_pilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 220, -1));

        Btn_afficher_pilote.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_afficher_pilote.setText("Afficher tous les pilotes");
        Btn_afficher_pilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_afficher_piloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_afficher_pilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 220, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setText("Gestion des pilotes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 280, 50));

        Btm_retour.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btm_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 270, 47, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, 48, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\admin 1.png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_ajouter_piloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ajouter_piloteActionPerformed
        //ajouter un pilote
        AjoutPilote fenetre_ajoutPilote= new AjoutPilote();
        fenetre_ajoutPilote.setLocationRelativeTo(null);
        fenetre_ajoutPilote.setVisible(true);
    }//GEN-LAST:event_Btn_ajouter_piloteActionPerformed

    private void Btn_afficher_piloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_afficher_piloteActionPerformed
        // afficher la liste de tous les pilotes
         AffichagePilote fenetre_affichPilote= new AffichagePilote();
         fenetre_affichPilote.setLocationRelativeTo(null);
         fenetre_affichPilote.setVisible(true);
    }//GEN-LAST:event_Btn_afficher_piloteActionPerformed

    private void Btm_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btm_retourActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Espace_pilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Espace_pilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Espace_pilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Espace_pilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Espace_pilote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btm_retour;
    private javax.swing.JButton Btn_afficher_pilote;
    private javax.swing.JButton Btn_ajouter_pilote;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
