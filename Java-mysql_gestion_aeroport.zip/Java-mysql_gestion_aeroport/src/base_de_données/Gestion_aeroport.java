package base_de_données;



public class Gestion_aeroport extends javax.swing.JFrame {

 
    public Gestion_aeroport() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        Btn_espace_clients = new javax.swing.JButton();
        Btn_espace_vols = new javax.swing.JButton();
        Btn_espace_pilotes = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        Btn_espace_pilotes1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel2.setText("Menu ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        Btn_espace_clients.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_espace_clients.setText("Gestion des clients");
        Btn_espace_clients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_espace_clientsActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_espace_clients, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 240, 33));

        Btn_espace_vols.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_espace_vols.setText("Gestion des vols");
        Btn_espace_vols.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_espace_volsActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_espace_vols, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 240, 33));

        Btn_espace_pilotes.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_espace_pilotes.setText("Gestion des pilotes");
        Btn_espace_pilotes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_espace_pilotesActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_espace_pilotes, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 240, 33));

        Btn_quitter.setBackground(new java.awt.Color(255, 0, 0));
        Btn_quitter.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 380, 50, 30));

        Btn_espace_pilotes1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Btn_espace_pilotes1.setText("Gestion des réservations");
        Btn_espace_pilotes1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_espace_pilotes1ActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_espace_pilotes1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 240, 33));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\bon.png")); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_espace_pilotesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_espace_pilotesActionPerformed
        // fenetre espace pilote
        Espace_pilote fenetre_pilotes = new Espace_pilote();
        fenetre_pilotes.setLocationRelativeTo(null);
        fenetre_pilotes.setVisible(true);
        
    }//GEN-LAST:event_Btn_espace_pilotesActionPerformed

    private void Btn_espace_volsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_espace_volsActionPerformed
        // fenetre espace vols
        Espace_vols fenetre_vols = new Espace_vols();
        fenetre_vols.setLocationRelativeTo(null);
        fenetre_vols.setVisible(true);
    }//GEN-LAST:event_Btn_espace_volsActionPerformed

    private void Btn_espace_clientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_espace_clientsActionPerformed
        // fenetre espace client
        Espace_clients fenetre_clients = new Espace_clients();
        fenetre_clients.setLocationRelativeTo(null);
        fenetre_clients.setVisible(true);
    }//GEN-LAST:event_Btn_espace_clientsActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    private void Btn_espace_pilotes1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_espace_pilotes1ActionPerformed
       // Touvrir la fenetre réservation
        Réservation fenetre_réserv= new Réservation();
        fenetre_réserv.setLocationRelativeTo(null);
        fenetre_réserv.setVisible(true);
    }//GEN-LAST:event_Btn_espace_pilotes1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gestion_aeroport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gestion_aeroport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gestion_aeroport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gestion_aeroport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gestion_aeroport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_espace_clients;
    private javax.swing.JButton Btn_espace_pilotes;
    private javax.swing.JButton Btn_espace_pilotes1;
    private javax.swing.JButton Btn_espace_vols;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
