import java.sql.*;

public class Connecter {
    Connection con;
    
    public Connecter(){
        
        // chargement du pilote
      try{ Class.forName("com.mysql.cj.jdbc.Driver");
      System.out.println("chargement du pilote réussi");
              }
      catch(ClassNotFoundException e){
         System.err.println(e); //pour afficher l erreur     
         }
      
      //connexion à la base de données
      try{
          con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aeroport?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
      System.out.println("connexion à la base de données réussie");}
      
      catch(SQLException ex){
         System.err.println(ex);
         }
      
    }
   
 Connection obtenirconnexion(){return con;}
}
