
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class AjoutPilote extends javax.swing.JFrame {

   
    Connecter conn=new Connecter();
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model=new DefaultTableModel();
    
    public AjoutPilote() {
        initComponents();
        
model.addColumn("matricule");
model.addColumn("nom");
model.addColumn("prénom");
model.addColumn("adresse");
try {
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from pilote");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
    Rs.getString("adresse")});

}
}catch(Exception e){System.err.println(e);}

tble_pilote.setModel(model);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tble_pilote = new javax.swing.JTable();
        txtma = new javax.swing.JTextField();
        txtno = new javax.swing.JTextField();
        txtpr = new javax.swing.JTextField();
        txtad = new javax.swing.JTextField();
        matr = new javax.swing.JLabel();
        no = new javax.swing.JLabel();
        pré = new javax.swing.JLabel();
        adr = new javax.swing.JLabel();
        Btm_ajouterPilote = new javax.swing.JButton();
        Btm_ActualiserPilote = new javax.swing.JButton();
        Btm_retour = new javax.swing.JButton();
        Btn_quitter = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(738, 429));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel1.setText("Espace pilotes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 173, -1));

        tble_pilote.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tble_pilote.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tble_piloteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tble_pilote);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 84, -1, 147));

        txtma.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtma, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 121, 107, -1));

        txtno.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtno, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 166, 107, -1));

        txtpr.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(txtpr, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 210, 107, -1));

        txtad.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtadActionPerformed(evt);
            }
        });
        getContentPane().add(txtad, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 255, 107, -1));

        matr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        matr.setText("matricule");
        getContentPane().add(matr, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 123, -1, -1));

        no.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        no.setText("nom");
        getContentPane().add(no, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 168, -1, -1));

        pré.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        pré.setText("prénom");
        getContentPane().add(pré, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 212, -1, -1));

        adr.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        adr.setText("adresse");
        getContentPane().add(adr, new org.netbeans.lib.awtextra.AbsoluteConstraints(37, 257, -1, -1));

        Btm_ajouterPilote.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_ajouterPilote.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\plus.png")); // NOI18N
        Btm_ajouterPilote.setText("Ajouter");
        Btm_ajouterPilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_ajouterPiloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_ajouterPilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 332, 122, 34));

        Btm_ActualiserPilote.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_ActualiserPilote.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\refresh.png")); // NOI18N
        Btm_ActualiserPilote.setText("Actualiser");
        Btm_ActualiserPilote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_ActualiserPiloteActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_ActualiserPilote, new org.netbeans.lib.awtextra.AbsoluteConstraints(481, 332, -1, 34));

        Btm_retour.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Btm_retour.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\retour.png")); // NOI18N
        Btm_retour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btm_retourActionPerformed(evt);
            }
        });
        getContentPane().add(Btm_retour, new org.netbeans.lib.awtextra.AbsoluteConstraints(755, 397, 47, -1));

        Btn_quitter.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Btn_quitter.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\Icones\\quitter.png")); // NOI18N
        Btn_quitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_quitterActionPerformed(evt);
            }
        });
        getContentPane().add(Btn_quitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 397, 48, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HD\\Documents\\GSTR 1\\S2\\2 Base de donnée\\projet java_mysql\\espace Pilote\\2 (1).png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 430));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
     private void deplace(int i){
     try{
       txtma.setText(model.getValueAt(i,0).toString());
       txtno.setText(model.getValueAt(i,1).toString());
       txtpr.setText(model.getValueAt(i,2).toString());
       txtad.setText(model.getValueAt(i,3).toString());
 
     } catch (Exception e) {System.err.println(e);
     JOptionPane.showMessageDialog(null,"erreur de deplacement"+e.getLocalizedMessage());}   
        
    }
     
      private void afficher(){
        try {
       model.setRowCount(0);
stm=conn.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("Select * from pilote");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
 Rs.getString("adresse")});

}
}catch(Exception e){System.err.println(e);}

tble_pilote.setModel(model);
    }
     
    private void tble_piloteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tble_piloteMouseClicked
        // table de la liste des pilotes
        try{
            int i=tble_pilote.getSelectedRow(); deplace(i);
        }
        catch(Exception e){JOptionPane.showMessageDialog(null,"erreur de deplacement "+e.getLocalizedMessage());}
    }//GEN-LAST:event_tble_piloteMouseClicked

    private void txtadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtadActionPerformed

    private void Btm_ajouterPiloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_ajouterPiloteActionPerformed
        // ajouter un pilote

        String ma=txtma.getText();
        String nom=txtno.getText();
        String prénom=txtpr.getText();
        String adresse=txtad.getText();
        
if( ma.trim().isEmpty() || nom.trim().isEmpty() || prénom.trim().isEmpty() || adresse.trim().isEmpty() ){
     JOptionPane.showMessageDialog(null,"Veuillez remplir tous les champs SVP!!!");
    }else{
        String requete="insert into pilote(matricule,nom,prénom,adresse)VALUES('"+ma+"','"+nom+"','"+prénom+"','"+adresse+"')";

        try{
            stm=conn.obtenirconnexion().createStatement();
            stm.executeUpdate(requete);
            JOptionPane.showMessageDialog(null,"le pilote a bien été ajouté");

            txtma.setText("");
            txtno.setText("");
            txtpr.setText("");
            txtad.setText("");

             //afficher();

        }catch(Exception ex){JOptionPane.showMessageDialog(null,ex.getMessage());}

}
    }//GEN-LAST:event_Btm_ajouterPiloteActionPerformed

    private void Btm_ActualiserPiloteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_ActualiserPiloteActionPerformed
        // actualiser
        try {
            model.setRowCount(0);
            stm=conn.obtenirconnexion().createStatement();
            ResultSet Rs=stm.executeQuery("select * from pilote");
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getString("matricule"),Rs.getString("nom"),Rs.getString("prénom"),
                    Rs.getString("adresse")});
                afficher();

        }
        }catch(Exception e){System.err.println(e);}

        tble_pilote.setModel(model);
    }//GEN-LAST:event_Btm_ActualiserPiloteActionPerformed

    private void Btm_retourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btm_retourActionPerformed
        this.dispose();
    }//GEN-LAST:event_Btm_retourActionPerformed

    private void Btn_quitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_quitterActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Btn_quitterActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AjoutPilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AjoutPilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AjoutPilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AjoutPilote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AjoutPilote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btm_ActualiserPilote;
    private javax.swing.JButton Btm_ajouterPilote;
    private javax.swing.JButton Btm_retour;
    private javax.swing.JButton Btn_quitter;
    private javax.swing.JLabel adr;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel matr;
    private javax.swing.JLabel no;
    private javax.swing.JLabel pré;
    private javax.swing.JTable tble_pilote;
    private javax.swing.JTextField txtad;
    private javax.swing.JTextField txtma;
    private javax.swing.JTextField txtno;
    private javax.swing.JTextField txtpr;
    // End of variables declaration//GEN-END:variables
}
